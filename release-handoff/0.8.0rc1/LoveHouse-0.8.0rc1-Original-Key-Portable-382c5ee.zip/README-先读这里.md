# Android 0.8.0rc1 原密钥电脑签名便携包

这里的 App APK 仍未签名，不能作为已完成覆盖升级的安装包。私钥留在原来的电脑；本 ZIP 不含私钥、密码或已签名发行 APK。

来源：PR #5 head `382c5ee45f66016af7117c2ad5a9c16cc2a75f9e`，实际 checkout merge commit `730cfb01d70d2eda62104c5ad8e46eac1e355069`，Android CI run `41021442251`。API28/API36各6项真实 debug instrumentation 测试通过；双方 unsigned App 字节完全相同。最后的原密钥签名 App 与重签 test APK 仍须单独验收。

原包名 `io.github.myflww.lovehouse.preview`、版本 `0.8.0rc1`、versionCode `2`；必须使用原证书 `ca4b184194816fe3617feaa841e11b47f5a9a9a00493e8cbc015210c04a3a4cc` 的原密钥。

在原密钥电脑解压此包。已有 Python3.11+、Java17+、Android SDK Build-Tools36.0.0 的终端中运行；只替换 Build-Tools路径、原keystore路径和既有alias，密码在提示时隐藏输入。此处带来的是已校验 SDK jar；aapt/zipalign 使用该电脑现有 SDK。

```powershell
python scripts/sign_android_upgrade.py `
  --unsigned-apk artifacts/LoveHouse-0.8.0rc1-Android-unsigned.apk `
  --expected-sha256 ac3f6e7ea43de8dbf8fd8cca79586ebcba13e872a4ef0c555549665398741bc6 `
  --apksigner-jar signing-tools/apksigner.jar --expected-signer-sha256 3716d9311e55d2b0918a2fd9d54ba9e406c5f6abeea700b287f11259bc163dec `
  --build-tools "C:\Android\Sdk\build-tools\36.0.0" `
  --keystore "D:\PrivateSigning\原来的发行密钥.jks" --alias "原来的密钥别名" `
  --output-apk signed-output/LoveHouse-0.8.0rc1-Android.apk
```

随后准备开发验收所需的 test APK。它原来为 debug 签名，需在原密钥机用同一原证书重签；它不是给普通用户安装的 App：

```powershell
python scripts/sign_android_upgrade.py --instrumentation `
  --unsigned-apk artifacts/LoveHouse-Android-instrumentation-test.apk `
  --expected-sha256 ca8031da86d608a3a149bbc6653f283844b16cd4e058b24212bd86ea19c102ae `
  --apksigner-jar signing-tools/apksigner.jar --expected-signer-sha256 3716d9311e55d2b0918a2fd9d54ba9e406c5f6abeea700b287f11259bc163dec `
  --build-tools "C:\Android\Sdk\build-tools\36.0.0" `
  --keystore "D:\PrivateSigning\原来的发行密钥.jks" --alias "原来的密钥别名" `
  --output-apk signed-output/LoveHouse-0.8.0rc1-test-signed.apk
```

两次都只在本机隐藏询问密码；密码通过 stdin 传给 Java，不放进参数、环境或文件。不能隐藏输入、错摘要、错包/targetPackage、错证书均停止。不要发送私钥或密码；签完只带回两个 APK 和各自 verification JSON。

`PORTABLE-MANIFEST.json` 和 `FILES-SHA256.json` 记录本包全部摘要及来源。本次 API28/API36 的两份实际 App 截图均为 1080×1920 PNG，文件签名和全部 chunk CRC 已验证，随两份原始 JUnit XML 一并保留。旧 bccc artifact 的错误文本图片未混入。本工具副本只为签名交接补了 instrumentation/jar选择模式，不改变冻结生产后端或旧candidate.json，不自动发布，不宣称最终已签名包/设备覆盖升级已验收。
