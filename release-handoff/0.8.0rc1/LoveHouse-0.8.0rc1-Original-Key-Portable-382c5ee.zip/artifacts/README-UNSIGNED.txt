This is a developer artifact, not an installable public release.
The APK is unsigned. Keep private signing keys outside Git and sign the verified APK with a persistent key.
apksigner.jar is an Android SDK Build-Tools developer utility; preserve its upstream licence notices.
